#list이용

Q = []

Q.append(1)
Q.append(2)
Q.append(3)

print(Q.pop(0))
print(Q.pop(0))
print(Q.pop(0))