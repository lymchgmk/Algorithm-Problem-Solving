import sys
sys.stdin = open("문자열 비교.txt", "r")

T = int(input())

for test_case in range(1, T+1):
    str1 = str(input())
    str2 = str(input())
    result = 0
    #
    if str1 in str2:
        result = 1
    else:
        result = 0

    print("#{} {}".format(test_case, result))