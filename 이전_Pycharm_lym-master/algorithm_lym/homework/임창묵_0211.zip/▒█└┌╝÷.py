import sys
sys.stdin = open("글자수.txt", "r")

T = int(input())

for test_case in range(1, T+1):
    str1 = input()
    str2 = input()
    max_cnt = 0

    for char in str1:
        cnt = str2.count(char)

        if max_cnt < cnt:
            max_cnt = cnt

    print("#{} {}".format(test_case, max_cnt))