def add(a, b):
    return a + b

def mul(a, b):
    return a * b

if __name__ == "__main__":
    print(add(10, 20))
    print(mul(10, 20))