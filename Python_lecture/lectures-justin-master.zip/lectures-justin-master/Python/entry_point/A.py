def func():
    print('function A.py')

if __name__ == "__main__":
    print('A.py가 직접 실행됨')
else:
    print('A.py가 import 되어 실행됨')