## 원본 자료
- `multicampus` 디렉토리 내에서 해당 원격 디렉토리 내용을 clone한다.
- 자료가 최신화 될때 마다 `$ git pull origin master` 를 통해 받아온다.
- **절대로 해당 디렉토리의 파일을 수정하지 않는다.**

## 정리 자료
- `multicampus` 자료를 `$ git pull origin master` 명령어를 통해 최신으로 업데이트 한 이후에 해당 파일을 `lectures` 디렉토리로 옮겨서 수업을 듣는다.