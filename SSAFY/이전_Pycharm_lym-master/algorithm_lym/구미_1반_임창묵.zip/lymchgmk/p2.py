import sys
sys.stdin = open("p2.txt", "r")

T = int(input())

for test_case in range(1, T+1):
    R, C, N = map(int, input().split())

    wall = [[0 for _ in range(C+1)] for _ in range(R+1)]

    for n in range(N):
        point = list(map(int, input().split()))
        for i in range(1, R+1):
            for j in range(1, C+1):
                if point[0] <= i <= point[2] and point[1] <= j <= point[3]:
                    wall[i][j] += 1

    darkest = max(max(wall))

    count = 0
    for i in range(1, R+1):
        for j in range(1, C+1):
            if wall[i][j] == darkest:
                count += 1

    print("#{} {}".format(test_case, count))