import sys
sys.stdin = open("p3.txt", "r")

def my_sum_list(data, x, y):
    result = [0]*4

    for i in range(N):
        for j in range(N):
            if i <= x and j <= y:
                result[0] += data[i][j]
            elif i <= x and y < j:
                result[1] += data[i][j]
            elif x < i and j <= y:
                result[2] += data[i][j]
            elif x < i and y < j:
                result[3] += data[i][j]

    list = [result[0], result[2], result[1] + result[3]]

    return list

T = int(input())

for test_case in range(1, T+1):
    N = int(input())

    data = []
    for n in range(N):
        data.append(list(map(int, input().split())))

    result = []
    for x in range(1, N-1):
        for y in range(1, N-1):
            temp_list = my_sum_list(data, x, y)

            result.append(max(temp_list) - min(temp_list))


    print("#{} {}".format(test_case, min(result)))