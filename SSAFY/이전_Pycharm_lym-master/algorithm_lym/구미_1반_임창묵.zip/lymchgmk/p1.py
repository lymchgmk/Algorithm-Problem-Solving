import sys
sys.stdin = open("p1.txt", "r")

T = int(input())

for test_case in range(1, T+1):
    A = list(map(int, input().split()))
    B = list(map(int, input().split()))
    sum_origin_A = 0
    sum_origin_B = 0
    sum_A = 0
    sum_B = 0

    data = []
    for case in range(10):
        data.append(list(map(int, input().split())))

    for i in range(10):
        for j in range(10):
            if A[0] <= i <= A[2] and A[1] <= j <= A[3]:
                sum_origin_A += data[i][j]
                if 2*data[i][j] >= 255:
                    data[i][j] = 255
                    sum_A += data[i][j]
                else:
                    data[i][j] = 2*data[i][j]
                    sum_A += data[i][j]

            elif B[0] <= i <= B[2] and B[1] <= j <= B[3]:
                sum_origin_B += data[i][j]
                data[i][j] = data[i][j] // 2
                sum_B += data[i][j]

    sum = abs(sum_A-sum_origin_A) + abs(sum_B-sum_origin_B)

    print("#{} {}".format(test_case, sum))