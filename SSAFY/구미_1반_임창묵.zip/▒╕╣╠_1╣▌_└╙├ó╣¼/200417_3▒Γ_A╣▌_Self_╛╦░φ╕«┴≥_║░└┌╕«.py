import sys
from collections import deque
sys.stdin=open('200417_3기_A반_Self_알고리즘_별자리.txt')

def issafe(data, x, y):
    if 0 <= x < len(data) and 0 <= y < len(data):
        return True
    else:
        return False

def bfs(start, mat):
    global visited
    dirs=[(1,0), (-1,0), (0,-1), (0,1), (1,1), (1,-1), (-1,1), (-1,-1)]
    q=deque()
    q.append(start)
    cnt=0

    while q:
        temp=q.popleft()
        x, y=temp[0], temp[1]

        if visited[x][y]==0:
            visited[x][y]=1
            cnt+=1

            for dir in dirs:
                test_x, test_y=x+dir[0], y+dir[1]

                if issafe(data, test_x, test_y) and visited[test_x][test_y]==0 and data[test_x][test_y]!=0:
                    q.append([test_x, test_y])

    return cnt


T=int(input())

for test_case in range(1, T+1):
    data=[list(map(int, input().split())) for _ in range(T)]

    visited=[[0 for _ in range(T)] for _ in range(T)]
    result=[]

    for i in range(T):
        for j in range(T):
            if data[i][j]==1 and visited[i][j]==0:
                start=[i, j]
                result.append(bfs(start, data))

    ans=len(result)

    print(f'#{test_case} {ans}')